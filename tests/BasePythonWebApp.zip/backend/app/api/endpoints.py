from fastapi import APIRouter
from datetime import datetime
from typing import Dict

router = APIRouter()


@router.get("/hello")
async def get_hello() -> Dict[str, str]:
    """Return a hello message with current timestamp."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return {"message": "Hello", "timestamp": timestamp}
