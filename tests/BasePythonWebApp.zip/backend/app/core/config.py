from pydantic import BaseSettings


class Settings(BaseSettings):
    """Application settings."""
    APP_NAME: str = "FastAPI Backend"
    API_PREFIX: str = "/api"
    DEBUG: bool = False

    class Config:
        env_file = ".env"


settings = Settings()