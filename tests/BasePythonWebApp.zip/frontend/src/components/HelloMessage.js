import { useState, useEffect } from 'react';
import { getHelloMessage } from '../services/api';

/**
 * Component to display hello message from the API
 */
const HelloMessage = () => {
  const [data, setData] = useState({ message: 'Loading...', timestamp: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const result = await getHelloMessage();
        setData(result);
        setError(null);
      } catch (err) {
        setError('Failed to fetch data from API');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    
    // Set up polling every 10 seconds to get updated timestamp
    const intervalId = setInterval(fetchData, 10000);
    
    // Clean up interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  if (loading && !data.message) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="hello-message">
      <h2>{data.message}</h2>
      <p>Current time: {data.timestamp}</p>
    </div>
  );
};

export default HelloMessage; 
