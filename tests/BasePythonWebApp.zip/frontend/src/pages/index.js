import Head from 'next/head';
import HelloMessage from '../components/HelloMessage';

export default function Home() {
  return (
    <div className="container">
      <Head>
        <title>Next.js + FastAPI App</title>
        <meta name="description" content="A simple app with Next.js frontend and FastAPI backend" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main>
        <h1>Welcome to Next.js + FastAPI App</h1>
        <div className="card">
          <HelloMessage />
        </div>
      </main>

      <style jsx>{`
        .container {
          min-height: 100vh;
          padding: 0 0.5rem;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
        }
        
        main {
          padding: 5rem 0;
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
        }
        
        h1 {
          margin: 0;
          line-height: 1.15;
          font-size: 4rem;
          text-align: center;
        }
        
        .card {
          margin: 1rem;
          padding: 1.5rem;
          text-align: left;
          color: inherit;
          text-decoration: none;
          border: 1px solid #eaeaea;
          border-radius: 10px;
          transition: color 0.15s ease, border-color 0.15s ease;
          width: 350px;
        }
      `}</style>
    </div>
  );
}
