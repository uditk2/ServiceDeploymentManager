/**
 * API client for backend communication
 */

// Base URL for API requests - in Docker environment, this will be the service name
const API_BASE_URL = process.browser 
  ? '/api' // Browser environment - use relative path
  : 'http://backend:8000/api'; // Server-side rendering - use Docker service name

/**
 * Get hello message with timestamp from the backend
 * @returns {Promise<Object>} Response with message and timestamp
 */
export const getHelloMessage = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/hello`);
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching hello message:', error);
    return { message: 'Error', timestamp: 'Failed to fetch from API' };
  }
};