import os
import json
import boto3
from flask import Flask, render_template, request, jsonify, session
from botocore.exceptions import ClientError

app = Flask(__name__)
app.secret_key = os.urandom(24)  # For session management

@app.route('/')
def index():
    """Render the main page with connection form."""
    return render_template('index.html')

@app.route('/connect', methods=['POST'])
def connect():
    """Connect to S3 with provided credentials and store in session."""
    try:
        # Get connection details from form
        access_key = request.form.get('access_key')
        secret_key = request.form.get('secret_key')
        region = request.form.get('region')
        bucket_name = request.form.get('bucket_name')
        
        # Store in session
        session['access_key'] = access_key
        session['secret_key'] = secret_key
        session['region'] = region
        session['bucket_name'] = bucket_name
        
        # Test connection
        s3_client = boto3.client(
            's3',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region
        )
        
        # Check if bucket exists and is accessible
        s3_client.head_bucket(Bucket=bucket_name)
        
        return render_template('explorer.html', bucket_name=bucket_name)
    
    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code', 'Unknown')
        if error_code == '403':
            error_message = "Access denied. Please check your credentials."
        elif error_code == '404':
            error_message = f"Bucket '{bucket_name}' not found."
        else:
            error_message = f"Error connecting to S3: {str(e)}"
        
        return render_template('index.html', error=error_message)
    
    except Exception as e:
        return render_template('index.html', error=f"Unexpected error: {str(e)}")

@app.route('/list', methods=['GET'])
def list_objects():
    """List objects in the bucket with a given prefix."""
    try:
        prefix = request.args.get('prefix', '')
        
        # Get session data
        access_key = session.get('access_key')
        secret_key = session.get('secret_key')
        region = session.get('region')
        bucket_name = session.get('bucket_name')
        
        if not all([access_key, secret_key, region, bucket_name]):
            return jsonify({'error': 'Session expired. Please reconnect.'}), 401
        
        # Create S3 client
        s3_client = boto3.client(
            's3',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region
        )
        
        # List objects with the given prefix
        response = s3_client.list_objects_v2(
            Bucket=bucket_name,
            Prefix=prefix,
            Delimiter='/'
        )
        
        # Process common prefixes (folders)
        folders = []
        if 'CommonPrefixes' in response:
            for common_prefix in response['CommonPrefixes']:
                folder_name = common_prefix['Prefix']
                # Remove the current prefix to get just the folder name
                if prefix:
                    relative_name = folder_name[len(prefix):]
                else:
                    relative_name = folder_name
                
                # Remove trailing slash
                if relative_name.endswith('/'):
                    relative_name = relative_name[:-1]
                
                folders.append({
                    'name': relative_name,
                    'path': folder_name,
                    'type': 'folder'
                })
        
        # Process objects (files)
        files = []
        if 'Contents' in response:
            for item in response['Contents']:
                # Skip the prefix itself if it's returned as a content item
                if item['Key'] == prefix:
                    continue
                
                # Remove the current prefix to get just the file name
                if prefix:
                    relative_name = item['Key'][len(prefix):]
                else:
                    relative_name = item['Key']
                
                # Skip if this is not a direct child (contains '/')
                if '/' in relative_name:
                    continue
                
                # Determine file type
                file_type = 'file'
                if item['Key'].lower().endswith('.json'):
                    file_type = 'json'
                
                files.append({
                    'name': relative_name,
                    'path': item['Key'],
                    'size': item['Size'],
                    'last_modified': item['LastModified'].isoformat(),
                    'type': file_type
                })
        
        return jsonify({
            'folders': folders,
            'files': files,
            'current_prefix': prefix
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/content', methods=['GET'])
def get_content():
    """Get the content of a specific file."""
    try:
        file_key = request.args.get('key', '')
        
        # Get session data
        access_key = session.get('access_key')
        secret_key = session.get('secret_key')
        region = session.get('region')
        bucket_name = session.get('bucket_name')
        
        if not all([access_key, secret_key, region, bucket_name]):
            return jsonify({'error': 'Session expired. Please reconnect.'}), 401
        
        # Create S3 client
        s3_client = boto3.client(
            's3',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region
        )
        
        # Get the object
        response = s3_client.get_object(
            Bucket=bucket_name,
            Key=file_key
        )
        
        # Read the content
        content = response['Body'].read().decode('utf-8')
        
        # If it's a JSON file, parse it to ensure it's valid JSON
        if file_key.lower().endswith('.json'):
            try:
                content = json.loads(content)
                return jsonify({
                    'content': content,
                    'is_json': True
                })
            except json.JSONDecodeError:
                # If JSON parsing fails, return as plain text
                return jsonify({
                    'content': content,
                    'is_json': False,
                    'warning': 'File has .json extension but contains invalid JSON'
                })
        
        # For non-JSON files, return as plain text
        return jsonify({
            'content': content,
            'is_json': False
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)